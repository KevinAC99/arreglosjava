/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package calculator;

/**
 *
 * @author Sistemas
 */
public interface SumaDAO {
    
    public double suma (double numero1, double numero2); 
    public double resta (double numero1, double numero2);
    public double multiplicacion (double numero1, double numero2);
    public double division (double numero1, double numero2);
    
}
